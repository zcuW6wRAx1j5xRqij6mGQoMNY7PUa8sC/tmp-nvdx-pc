const s="/assets/logo-XM5mPzFa.webp";export{s as _};
