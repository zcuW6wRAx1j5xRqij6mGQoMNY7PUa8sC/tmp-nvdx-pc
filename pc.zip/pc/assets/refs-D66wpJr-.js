import{a6 as c}from"./index-sRNqgdFD.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};
